package FourRowSolitaire;

import java.awt.*;

/**
 * Class: SingleCell
 * <p>
 * Description: The SingleCell class manages an individual cell that can only hold one card.
 *
 * @author Matt Stephen
 */
public class SingleCell extends CardStack {
    public SingleCell() {
    }

    public Card push(Card card) {
        if (isEmpty()) {
            super.push(card);
            return card;
        }

        return null;
    }

    public Card getCardAtLocation(Point p) {
        return peek();
    }

    public boolean isValidMove(Card card) {
        return isEmpty();

    }

    public boolean isValidMove(CardStack stack) {
        return false;
    }
}