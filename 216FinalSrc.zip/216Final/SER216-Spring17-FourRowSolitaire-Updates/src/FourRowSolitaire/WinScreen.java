package FourRowSolitaire;

import javax.sound.midi.MidiSystem;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.net.URL;
import java.util.Random;

//import java.awt.Dialog;

/**
 * Class: WinScreen
 * <p>
 * Description: The WinScreen class manages the win animation and sounds window.
 *
 * @author Matt Stephen
 */

/**
 * @author Brenden
 *
 */
public class WinScreen extends JFrame {
    SoundThread sound = null;

    public WinScreen(int animation, int sounds) {
        setUndecorated(true);
        //setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setFocusable(true);

        /*For JDialog instead of JFrame, but the mouse listener
            doesn't work with JDialog for some reason.
        setModalityType(Dialog.ModalityType.DOCUMENT_MODAL);*/

        if (sounds == 1) {
            setSize(200, 100);
            sound = new SoundThread();
            sound.run();
        }

        if (animation == 1) {
            setSize(800, 700);

            FireworksDisplay fw = new FireworksDisplay(100, 200);
            add(fw);
            fw.restartDisplay();
            setLocationRelativeTo(null);
        } else {
            Toolkit tk = Toolkit.getDefaultToolkit();
            Dimension screenSize = tk.getScreenSize();
            int screenHeight = screenSize.height;
            int screenWidth = screenSize.width;
            this.setLocation(screenWidth / 2, screenHeight / 4);
            add(new JLabel("Click Here to Stop Music"));
        }


        setVisible(true);

        addMouseListener(new MouseInputAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (sound != null && sound.sequencer.isRunning()) {
                    sound.sequencer.stop();
                }

                WinScreen.this.dispose();
            }
        });

        addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                WinScreen.this.requestFocus();
            }
        });
    }

    public void turnOff() {
        if (sound != null && sound.sequencer.isRunning()) {
            sound.sequencer.stop();
        }

        WinScreen.this.dispose();
    }

    private class SoundThread extends Thread {
        public Sequencer sequencer;

        public void run() {
            String song = ""; //To hold choice
            Random gen = new Random();

            try {
                //Doesn't work as a .jar
                File songDir = new File(getClass().getResource("sounds/win/").toURI());
                String[] songs = songDir.list();
                boolean retry = true;

                do {
                    song = songs[gen.nextInt(songs.length)];

                    if (song.toLowerCase().contains(".mid")) {
                        retry = false;
                    }
                } while (retry);
            } catch (Exception ex) {
                int songInt = gen.nextInt(4);

                if (songInt == 0) {
                    song = "celebration.mid";
                } else if (songInt == 1) {
                    song = "anotheronebitesthedust.mid";
                } else if (songInt == 2) {
                    song = "wearethechampions.mid";
                } else if (songInt == 3) {
                    song = "bluedabadee.mid";
                }
            }

            URL filelocation = getClass().getResource("sounds/win/" + song);

            try {
                Sequence sequence = MidiSystem.getSequence(filelocation);
                sequencer = MidiSystem.getSequencer();
                sequencer.open();
                sequencer.setSequence(sequence);
                sequencer.setLoopCount(0);
                sequencer.start();
            } catch (Exception ex) {
                System.err.println("Error opening win sound file.");
            }
        }
    }
}