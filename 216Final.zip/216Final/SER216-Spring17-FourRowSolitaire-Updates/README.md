# SER216-Spring17-FourRowSolitaire

Base Code: FourRowSolitaire by Matt Stephen v-.76

Modification Contributors:
  Kai Chen
  Rahul Dawar
  Teresa Pino
  Gema Trejo
  
  Updates:
    -GUI work
    -Updated logos
    -Bug fixes
